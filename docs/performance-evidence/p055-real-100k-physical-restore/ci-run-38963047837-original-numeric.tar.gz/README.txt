P055 source-exact original n3 numeric subset from GitHub Actions. Files: 11 source, 8 preserved original bytes plus manifest and README.
