CAS-A02c first source-exact valid n=3, GitHub Actions run #38971859757
Source exact work HEAD: 46e80a71734d4f4b0bc16943f6c7d7cf2d1031ae
This permanent archive contains the ORIGINAL eight numeric/source/resource files byte-for-byte.
Three large verbose .log files are not included, but their original SHA-256/size are in MANIFEST.json,
and the original full 11-member GitHub Actions artifact has its own short-retention download.
